"""Claude hooks: PostCompact stages; SessionStart source=compact injects."""

from __future__ import annotations

import hashlib
import json
import os
import re
import stat
from collections.abc import Mapping
from dataclasses import dataclass
from pathlib import Path
from typing import Final, Literal, override

from pydantic import TypeAdapter

from sb.contracts import PageSpec
from sb.memory_records import MemoryRecordError, parse_page_records
from sb.search import SearchHit, SearchIndex
from sb.search_errors import SearchQueryError
from sb.search_query import MAX_QUERY_BYTES, MAX_QUERY_GROUPS, LexicalQuery, normalize
from sb.vault import read_page_spec

_POSTCOMPACT: Final = "PostCompact"
_PROMPT: Final = "UserPromptSubmit"
_SESSION: Final = "SessionStart"
_MAX_ITEMS: Final = 8
_MAX_EXCERPT_BYTES: Final = 4_096
_MAX_TOTAL_BYTES: Final = 16_384
_MAX_CANDIDATE_TOKENS: Final = 32
_SHORT_TERM: Final = 6
_WORD_TOKEN: Final = re.compile(r"[0-9A-Za-z\uAC00-\uD7A3]+")
_HOOK_STOP: Final = frozenset({
    "a", "an", "and", "are", "as", "at", "be", "but", "by", "for",
    "from", "had", "has", "have", "he", "her", "his", "if", "in",
    "into", "is", "it", "its", "of", "on", "or", "our", "out", "so",
    "than", "that", "the", "their", "them", "then", "there", "these",
    "they", "this", "to", "was", "we", "were", "what", "when", "which",
    "who", "will", "with", "would", "you",
})
type Json = str | int | float | bool | None | list["Json"] | dict[str, "Json"]
type Trigger = Literal["auto", "manual", ""]
type HookName = Literal["PostCompact", "UserPromptSubmit", "SessionStart"]
_HOOK_JSON: Final[TypeAdapter[Json]] = TypeAdapter(Json)


class PostCompactHookError(ValueError):
    """Malformed or unsupported Claude hook stdin."""

    def __init__(self, code: str) -> None:
        self.code: str = code
        super().__init__(code)

    @override
    def __str__(self) -> str:
        return self.code


@dataclass(frozen=True, slots=True)
class PostCompactEvent:
    name: HookName
    session_id: str
    query: str
    trigger: Trigger
    event_digest: str
    source: str = ""


@dataclass(frozen=True, slots=True)
class PostCompactResult:
    session_id: str
    hook_payload: dict[str, Json]
    records: tuple[dict[str, str], ...]
    budgets: dict[str, int]
    duplicate: bool
    pending_confirm: bool = False


def parse_postcompact_event(raw: bytes) -> PostCompactEvent:
    """Parse Claude PostCompact or UserPromptSubmit stdin."""
    try:
        loaded = _HOOK_JSON.validate_python(json.loads(raw.decode("utf-8")), strict=True)
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise PostCompactHookError("HOOK_JSON_INVALID") from exc
    if not isinstance(loaded, dict):
        raise PostCompactHookError("HOOK_JSON_INVALID")
    name = _str_field(loaded, "hook_event_name", "hookEventName")
    session_id = _str_field(loaded, "session_id")
    if not session_id:
        raise PostCompactHookError("HOOK_SESSION_MISSING")
    match name:
        case "PostCompact":
            summary = _str_field(loaded, "query", "compact_summary")
            if not summary:
                raise PostCompactHookError("HOOK_QUERY_MISSING")
            _assert_quoted_syntax(summary)
            query = _bound_query_text(summary)
            trigger = _trigger(_str_field(loaded, "trigger", "matcher"))
            digest = _event_digest(session_id, summary, loaded)
            return PostCompactEvent(name, session_id, query, trigger, digest)
        case "UserPromptSubmit":
            prompt = _str_field(loaded, "prompt", "content", "query")
            query = _bound_query_text(prompt) if prompt else ""
            digest = _str_field(loaded, "event_digest")
            return PostCompactEvent(name, session_id, query, "", digest)
        case "SessionStart":
            source = _str_field(loaded, "source")
            summary = _str_field(loaded, "query", "compact_summary")
            query = _bound_query_text(summary) if summary else ""
            trigger = _trigger(_str_field(loaded, "trigger", "matcher"))
            digest = _event_digest(session_id, summary, loaded)
            return PostCompactEvent(name, session_id, query, trigger, digest, source)
        case _:
            raise PostCompactHookError("HOOK_EVENT_UNSUPPORTED")


def select_search_query(summary: str) -> str:
    """Turn a compaction summary into a lexical query that fits search limits."""
    stripped = summary.strip()
    if not stripped:
        raise PostCompactHookError("HOOK_QUERY_MISSING")
    encoded = stripped.encode()
    text = stripped
    if len(encoded) > MAX_QUERY_BYTES:
        text = encoded[:MAX_QUERY_BYTES].decode("utf-8", errors="ignore")
        if " " in text:
            text = text.rsplit(" ", 1)[0]
    tokens = [token for token in text.split() if token]
    if len(tokens) > MAX_QUERY_GROUPS:
        text = " ".join(tokens[:MAX_QUERY_GROUPS])
    return LexicalQuery.parse(text).text


def _assert_quoted_syntax(summary: str) -> None:
    if '"' not in summary:
        return
    try:
        _ = LexicalQuery.parse(summary)
    except SearchQueryError as exc:
        code = str(exc)
        if "TOO_MANY_GROUPS" in code or "TOO_LARGE" in code:
            return
        raise


def handle_postcompact(
    raw: bytes, index: SearchIndex, state_root: Path | None = None,
) -> PostCompactResult:
    """PostCompact stages reselect; UserPromptSubmit emits documented additionalContext."""
    event = parse_postcompact_event(raw)
    stage_root = state_root if state_root is not None else index.vault_root
    budgets = {
        "max_items": _MAX_ITEMS,
        "max_excerpt_bytes": _MAX_EXCERPT_BYTES,
        "max_total_bytes": _MAX_TOTAL_BYTES,
    }
    match event.name:
        case "PostCompact":
            hits, terms = _hook_search(index, event.query)
            search_event = PostCompactEvent(
                event.name, event.session_id, " ".join(terms), event.trigger,
                event.event_digest, event.source,
            )
            records, context = serialize(search_event, hits, index.vault_root)
            prior = _read_stage(stage_root, event.session_id)
            excluded = _exclude_delivered(records, prior)
            duplicate = prior is not None and str(prior.get("event_digest")) == event.event_digest
            last_query = _stage_last_query(prior, " ".join(terms) if terms else "")
            if not duplicate:
                remainder_ctx = _context_text(event.session_id, list(excluded)) if excluded else context
                _write_stage(
                    stage_root, event, excluded, remainder_ctx if excluded else "",
                    last_query=last_query,
                    delivered_in_turn=_delivered_in_turn(prior),
                    delivered=not excluded,
                )
            return PostCompactResult(event.session_id, {}, excluded, budgets, duplicate)
        case "UserPromptSubmit":
            stage = _read_stage(stage_root, event.session_id)
            _terms, useful = _hook_search(index, event.query) if event.query else ((), ())
            if useful:
                _remember_last_query(stage_root, event.session_id, " ".join(useful), stage)
            if stage is None:
                return PostCompactResult(event.session_id, {}, (), budgets, False)
            if stage.get("delivered") is True:
                return PostCompactResult(event.session_id, {}, (), budgets, True)
            records = _records_from_stage(stage)
            if not records:
                return PostCompactResult(event.session_id, {}, (), budgets, False)
            context = str(stage.get("context") or "")
            payload = inject_payload(_PROMPT, context)
            return PostCompactResult(event.session_id, payload, records, budgets, False, True)
        case "SessionStart":
            if event.source != "compact":
                return PostCompactResult(event.session_id, {}, (), budgets, False)
            prior = _read_stage(stage_root, event.session_id)
            query = event.query or _stage_last_query(prior, "")
            if not query:
                return PostCompactResult(event.session_id, {}, (), budgets, False)
            duplicate = (
                prior is not None
                and str(prior.get("event_digest")) == event.event_digest
                and prior.get("delivered") is True
            )
            if duplicate:
                return PostCompactResult(event.session_id, {}, (), budgets, True)
            hits, terms = _hook_search(index, query)
            search_event = PostCompactEvent(
                event.name, event.session_id, " ".join(terms) or query, event.trigger,
                event.event_digest, event.source,
            )
            records, context = serialize(search_event, hits, index.vault_root)
            if not records:
                return PostCompactResult(event.session_id, {}, (), budgets, False)
            prior_undelivered = () if prior is None or prior.get("delivered") is True else _records_from_stage(prior)
            in_turn_keys = {_record_key(rec) for rec in records}
            remainder = tuple(rec for rec in prior_undelivered if _record_key(rec) not in in_turn_keys)
            remainder_ctx = _context_text(event.session_id, list(remainder))
            _write_stage(
                stage_root, event, remainder, remainder_ctx,
                last_query=" ".join(terms) or query,
                delivered_in_turn=list(in_turn_keys),
                delivered=not remainder,
                in_turn=records,
            )
            payload = inject_payload(_SESSION, context)
            return PostCompactResult(event.session_id, payload, records, budgets, False, True)


def confirm_delivery(root: Path, session_id: str) -> None:
    """Mark staged context delivered only after stdout succeeded."""
    stage = _read_stage(root, session_id)
    if stage is None:
        return
    seen = _delivered_in_turn(stage)
    in_turn = _records_from_stage_field(stage, "in_turn")
    if in_turn:
        for rec in in_turn:
            key = _record_key(rec)
            if key and key not in seen:
                seen.append(key)
        stage["in_turn"] = []
        stage["delivered"] = not _records_from_stage(stage)
    else:
        for rec in _records_from_stage(stage):
            key = _record_key(rec)
            if key and key not in seen:
                seen.append(key)
        stage["delivered"] = True
    stored_keys: list[Json] = list(seen)
    stage["delivered_in_turn"] = stored_keys
    _write_stage_file(_stage_path(root, session_id), json.dumps(stage, ensure_ascii=False))


def _record_key(record: dict[str, str]) -> str:
    return f"{record.get('record_id', '')}\0{record.get('version', '')}"


def _delivered_in_turn(stage: dict[str, Json] | None) -> list[str]:
    if stage is None:
        return []
    raw = stage.get("delivered_in_turn")
    if not isinstance(raw, list):
        return []
    return [str(item) for item in raw if isinstance(item, str)]


def _exclude_delivered(
    records: tuple[dict[str, str], ...], stage: dict[str, Json] | None,
) -> tuple[dict[str, str], ...]:
    blocked = set(_delivered_in_turn(stage))
    if not blocked:
        return records
    return tuple(rec for rec in records if _record_key(rec) not in blocked)


def _stage_last_query(stage: dict[str, Json] | None, fallback: str) -> str:
    if stage is not None:
        prior = stage.get("last_query")
        if isinstance(prior, str) and prior.strip():
            return prior.strip()
    return fallback


def _remember_last_query(
    root: Path, session_id: str, last_query: str, stage: dict[str, Json] | None,
) -> None:
    payload: dict[str, Json] = dict(stage) if stage is not None else {
        "session_id": session_id,
        "delivered": False,
        "records": [],
    }
    payload["last_query"] = last_query
    _write_stage_file(_stage_path(root, session_id), json.dumps(payload, ensure_ascii=False))


def _trigger(value: str) -> Trigger:
    match value:
        case "auto" | "manual" | "":
            return value
        case _:
            return ""


def _str_field(payload: Mapping[str, Json], *keys: str) -> str:
    for key in keys:
        value = payload.get(key)
        if isinstance(value, str) and value.strip():
            return value.strip()
    return ""


def _occurrence_id(payload: Mapping[str, Json]) -> str:
    parts: list[str] = []
    for key in (
        "prompt_id", "promptId", "compaction_id", "compactionId",
        "event_id", "eventId", "uuid",
    ):
        value = _str_field(payload, key)
        if value:
            parts.append(f"{key}={value}")
    return "\0".join(parts)


def _event_digest(session_id: str, summary: str, payload: Mapping[str, Json]) -> str:
    occurrence = _occurrence_id(payload)
    material = f"{session_id}\0{occurrence}\0{summary}".encode()
    return f"sha256:{hashlib.sha256(material).hexdigest()}"


def _bound_query_text(text: str) -> str:
    stripped = text.strip()
    if not stripped:
        return ""
    encoded = stripped.encode()
    if len(encoded) <= MAX_QUERY_BYTES:
        return stripped
    return encoded[:MAX_QUERY_BYTES].decode("utf-8", errors="ignore")


def _standalone_term(term: str, text: str) -> bool:
    folded = term.casefold()
    return any(match.group().casefold() == folded for match in _WORD_TOKEN.finditer(text))


def _term_in(term: str, text: str) -> bool:
    if len(term) < _SHORT_TERM:
        return _standalone_term(term, text)
    compact = normalize(term)
    return bool(compact) and compact in normalize(text)


def _identifier_rank(token: str) -> int:
    upper = any("A" <= char <= "Z" for char in token)
    lower = any("a" <= char <= "z" for char in token)
    hangul = any(0xAC00 <= ord(char) <= 0xD7A3 for char in token)
    if hangul or (upper and lower):
        return 0
    if any(char.isdigit() for char in token):
        return 1
    return 2


def candidate_tokens(text: str) -> tuple[str, ...]:
    counts: dict[str, tuple[int, str]] = {}
    for raw in text.split():
        token = raw.strip(".,;:!?\"'()[]")
        folded = token.casefold()
        if len(folded) < 3 or folded in _HOOK_STOP:
            continue
        prior = counts.get(folded)
        if prior is None:
            counts[folded] = (1, token)
        else:
            counts[folded] = (prior[0] + 1, prior[1])
    ranked = sorted(
        counts,
        key=lambda folded: (
            -counts[folded][0],
            _identifier_rank(counts[folded][1]),
            -len(counts[folded][1]),
            folded,
        ),
    )
    return tuple(counts[key][1] for key in ranked[:_MAX_CANDIDATE_TOKENS])


def _weighted_terms(
    index: SearchIndex, text: str,
) -> tuple[tuple[str, float, tuple[SearchHit, ...]], ...]:
    limit = _MAX_ITEMS * 4
    weighted: list[tuple[str, float, tuple[SearchHit, ...]]] = []
    for term in candidate_tokens(text):
        hits = index.search(term, limit)
        if len(term) < _SHORT_TERM:
            hits = tuple(hit for hit in hits if _standalone_term(term, hit.snippet))
        count = len(hits)
        if count == 0 or count >= limit:
            continue
        weighted.append((term, 1.0 / count, hits))
    return tuple(weighted)


def _hook_search(
    index: SearchIndex, text: str,
) -> tuple[tuple[SearchHit, ...], tuple[str, ...]]:
    weighted = _weighted_terms(index, text)
    if not weighted:
        return (), ()
    scored: dict[str, tuple[float, int, SearchHit]] = {}
    for _term, weight, hits in weighted:
        for rank, hit in enumerate(hits):
            key = f"{hit.page_id}\0{hit.section}"
            prior = scored.get(key)
            if prior is None:
                scored[key] = (weight, rank, hit)
            else:
                scored[key] = (prior[0] + weight, min(prior[1], rank), prior[2])
    ordered = sorted(scored.values(), key=lambda row: (-row[0], row[1]))
    return tuple(row[2] for row in ordered), tuple(term for term, _weight, _hits in weighted)


_CITATION_DEF = re.compile(r"^\[\^([0-9a-f]{8,64})\]:\s*(\S.*)$")


def _page_file(root: Path, page_id: str) -> Path | None:
    names = [page_id]
    if page_id.startswith("wiki/"):
        names.append(page_id.removeprefix("wiki/"))
    else:
        names.append(f"wiki/{page_id}")
    root_resolved = root.resolve()
    for name in names:
        path = root / f"{name}.md"
        if path.is_file() and path.resolve().is_relative_to(root_resolved):
            return path
    return None


def _spec_for(root: Path, page_id: str) -> PageSpec | None:
    for candidate in (page_id, page_id.removeprefix("wiki/")):
        spec = read_page_spec(root, candidate)
        if spec is not None:
            return spec
    return None


def _origin_for(spec: PageSpec | None, sid: str, raw: bytes) -> str:
    if spec is not None:
        for cite in spec.sources:
            if cite.sid == sid:
                return cite.origin
    for line in raw.decode("utf-8").splitlines():
        matched = _CITATION_DEF.fullmatch(line.strip())
        if matched is not None and matched.group(1) == sid:
            return matched.group(2)
    return ""


def _matching_records(root: Path, hit: SearchHit, terms: tuple[str, ...]) -> tuple[dict[str, str], ...]:
    path = _page_file(root, hit.page_id)
    spec = _spec_for(root, hit.page_id)
    parsed = ()
    raw = b""
    if path is not None:
        raw = path.read_bytes()
        try:
            parsed = parse_page_records(raw, hit.page_id)
        except MemoryRecordError:
            parsed = ()
    selected = tuple(
        rec for rec in parsed
        if any(_term_in(term, rec.record_text) for term in terms)
    ) if terms else ()
    rows: list[dict[str, str]] = []
    for rec in selected:
        rows.append({
            "page_id": hit.page_id,
            "source_ref": _origin_for(spec, rec.sid, raw),
            "record_id": rec.record_id,
            "version": rec.record_digest,
            "snippet": _clip(rec.record_text, _MAX_EXCERPT_BYTES),
        })
    return tuple(rows)


def serialize(
    event: PostCompactEvent, hits: tuple[SearchHit, ...], root: Path | None = None,
) -> tuple[tuple[dict[str, str], ...], str]:
    terms = candidate_tokens(event.query)
    seen: set[str] = set()
    records: list[dict[str, str]] = []
    for hit in hits:
        matched = _matching_records(root, hit, terms) if root is not None else ({
            "page_id": hit.page_id,
            "source_ref": hit.source_ref,
            "record_id": hit.record_id,
            "version": hit.record_digest,
            "snippet": _clip(hit.snippet, _MAX_EXCERPT_BYTES),
        },)
        for rec in matched:
            key = rec["record_id"] or f"{rec['page_id']}:{rec['snippet']}"
            if key in seen:
                continue
            seen.add(key)
            records.append(rec)
            if len(records) >= _MAX_ITEMS:
                break
        if len(records) >= _MAX_ITEMS:
            break
    while True:
        context = _context_text(event.session_id, records)
        inject_name = _SESSION if event.name == "SessionStart" else _PROMPT
        payload = inject_payload(inject_name, context)
        encoded = json.dumps(payload, ensure_ascii=False).encode()
        if len(encoded) <= _MAX_TOTAL_BYTES:
            return tuple(records), context
        if not records:
            return (), _context_text(event.session_id, [])
        _ = records.pop()


def _context_text(session_id: str, records: list[dict[str, str]]) -> str:
    lines = [
        f"session_id: {session_id}",
        (
            f"budget: items<={_MAX_ITEMS} excerpt<={_MAX_EXCERPT_BYTES} "
            + f"total<={_MAX_TOTAL_BYTES}"
        ),
    ]
    for record in records:
        lines.append(
            f"record page_id={record['page_id']} source_ref={record['source_ref']} "
            + f"record_id={record['record_id']} version={record['version']}\n{record['snippet']}",
        )
    return "\n".join(lines)


def inject_payload(event_name: str, context: str) -> dict[str, Json]:
    return {
        "hookSpecificOutput": {
            "hookEventName": event_name,
            "additionalContext": context,
        },
    }


def _stage_path(root: Path, session_id: str) -> Path:
    folder = root / ".sb" / "session-memory"
    folder.parent.mkdir(parents=True, exist_ok=True)
    try:
        os.mkdir(folder, 0o700)
    except FileExistsError:
        pass
    try:
        dir_fd = os.open(folder, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC)
    except OSError as exc:
        raise PostCompactHookError("HOOK_STAGE_UNSAFE") from exc
    os.close(dir_fd)
    safe = "".join(char if char.isalnum() or char in "-_" else "_" for char in session_id)[:128]
    return folder / f"{safe}.json"


def _write_stage_file(path: Path, text: str) -> None:
    encoded = text.encode()
    flags = os.O_WRONLY | os.O_CREAT | os.O_NOFOLLOW | os.O_CLOEXEC | os.O_NONBLOCK
    try:
        fd = os.open(path, flags, 0o600)
    except OSError as exc:
        raise PostCompactHookError("HOOK_STAGE_UNSAFE") from exc
    try:
        if not stat.S_ISREG(os.fstat(fd).st_mode):
            raise PostCompactHookError("HOOK_STAGE_UNSAFE")
        os.ftruncate(fd, 0)
        written = os.write(fd, encoded)
        if written != len(encoded):
            raise PostCompactHookError("HOOK_STAGE_UNSAFE")
        os.fsync(fd)
    finally:
        os.close(fd)


def _read_stage(root: Path, session_id: str) -> dict[str, Json] | None:
    path = _stage_path(root, session_id)
    if not path.is_file():
        return None
    loaded = _HOOK_JSON.validate_python(
        json.loads(path.read_text(encoding="utf-8")), strict=True,
    )
    if not isinstance(loaded, dict):
        return None
    return loaded


def _record_payload(record: dict[str, str]) -> dict[str, Json]:
    return {
        "page_id": record["page_id"],
        "source_ref": record["source_ref"],
        "record_id": record["record_id"],
        "version": record["version"],
        "snippet": record["snippet"],
    }


def _write_stage(
    root: Path, event: PostCompactEvent, records: tuple[dict[str, str], ...], context: str,
    last_query: str = "",
    delivered_in_turn: list[str] | None = None,
    delivered: bool = False,
    in_turn: tuple[dict[str, str], ...] | None = None,
) -> None:
    stored: list[Json] = [_record_payload(record) for record in records]
    payload: dict[str, Json] = {
        "session_id": event.session_id,
        "event_digest": event.event_digest,
        "delivered": delivered,
        "context": context,
        "records": stored,
        "last_query": last_query,
        "delivered_in_turn": [key for key in (delivered_in_turn or [])],
        "in_turn": [_record_payload(record) for record in (in_turn or ())],
    }
    _write_stage_file(_stage_path(root, event.session_id), json.dumps(payload, ensure_ascii=False))


def _records_from_stage(stage: dict[str, Json]) -> tuple[dict[str, str], ...]:
    return _records_from_stage_field(stage, "records")


def _records_from_stage_field(stage: dict[str, Json], field: str) -> tuple[dict[str, str], ...]:
    raw = stage.get(field)
    if not isinstance(raw, list):
        return ()
    records: list[dict[str, str]] = []
    for item in raw:
        if not isinstance(item, dict):
            continue
        records.append({
            "page_id": str(item.get("page_id") or ""),
            "source_ref": str(item.get("source_ref") or ""),
            "record_id": str(item.get("record_id") or ""),
            "version": str(item.get("version") or ""),
            "snippet": str(item.get("snippet") or ""),
        })
    return tuple(records)


def _clip(text: str, max_bytes: int) -> str:
    encoded = text.encode()
    if len(encoded) <= max_bytes:
        return text
    return encoded[:max_bytes].decode("utf-8", errors="ignore")


# Compatibility for existing internal consumers; public names own the implementations.
_serialize = serialize
_inject_payload = inject_payload
_candidate_tokens = candidate_tokens
